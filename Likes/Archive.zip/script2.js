var likecount1 = 9;
var liketag1 = document.querySelector("#likes1");

function add1() {
  likecount1++;
  liketag1.innerText = likecount1 + " like(s)";
}

//  2nd
var likecount2 = 12;
var liketag2 = document.querySelector("#likes2");

function add2() {
  likecount2++;
  liketag2.innerText = likecount2 + " like(s)";
}

// 3rd
var likecount3 = 9;
var liketag3 = document.querySelector("#likes3");

function add3() {
  likecount3++;
  liketag3.innerText = likecount3 + " like(s)";
}
