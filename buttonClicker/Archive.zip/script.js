function changeText(element) {
  element.innerText = "Logout";
}

function hide(element) {
  element.remove();
}
